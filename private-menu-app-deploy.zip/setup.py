from setuptools import setup


setup(
    name="private-menu-app",
    version="0.1.0",
    description="Private menu ordering app with customer menu, cart, orders, and admin dashboard.",
    py_modules=["server"],
    data_files=[
        (
            "",
            [
                "index.html",
                "styles.css",
                "app.js",
                "manifest.webmanifest",
                "sw.js",
                "README.md",
                "PUBLIC_DEPLOY.md",
            ],
        ),
        ("icons", ["icons/icon.svg"]),
        ("scripts", ["scripts/check_regressions.py"]),
    ],
    entry_points={
        "console_scripts": [
            "private-menu-app=server:main",
        ],
    },
    python_requires=">=3.8",
)
