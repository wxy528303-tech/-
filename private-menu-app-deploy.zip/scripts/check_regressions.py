#!/usr/bin/env python3
"""Static regression checks for the private menu app's core order flow."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP_JS = (ROOT / "app.js").read_text(encoding="utf-8")
INDEX_HTML = (ROOT / "index.html").read_text(encoding="utf-8")
SETUP_PY = ROOT / "setup.py"

CHECKS = [
    ("deploy zip must be pip-installable on Aliyun", SETUP_PY.exists()),
    ("dish card plus must not bypass detail modal", "quick-add" not in APP_JS),
    ("dish card plus opens dish detail", 'class="add-btn" data-dish="${dish.id}"' in APP_JS),
    ("dish detail keeps taste selector", 'choiceGroup("口味", "taste"' in APP_JS),
    ("dish detail keeps remark input", 'id="dishRemark"' in APP_JS),
    ("cart checkout action exists", 'data-action="checkout"' in INDEX_HTML or 'action === "checkout"' in APP_JS),
    ("admin order detail action exists", 'view-order' in APP_JS),
    ("remote sync API base is configurable", "PRIVATE_MENU_API_BASE" in APP_JS),
]

failed = [name for name, passed in CHECKS if not passed]

if failed:
    print("Regression check failed:")
    for name in failed:
        print(f"- {name}")
    raise SystemExit(1)

print(f"Regression checks passed ({len(CHECKS)} checks).")
