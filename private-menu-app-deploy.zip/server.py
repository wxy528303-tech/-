#!/usr/bin/env python3
import json
import os
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT, "data")
STORE_PATH = os.path.join(DATA_DIR, "store.json")
DEFAULT_PASSWORD = "123456"


DEFAULT_DISHES = [
    {
        "id": 1,
        "name": "黑松露奶油意面",
        "category": "今日限定",
        "price": 68,
        "desc": "奶油酱低温慢熬，搭配黑松露香气，入口浓郁但不厚重。",
        "tags": ["招牌", "今日限定", "主厨推荐"],
        "image": "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=80",
        "specs": [{"name": "单人份", "price": 68}, {"name": "双人份", "price": 118}],
        "tastes": ["正常", "少盐", "少油"],
        "addons": [{"name": "加芝士", "price": 5}, {"name": "加虾仁", "price": 15}, {"name": "加温泉蛋", "price": 6}],
        "chefNote": "这道菜建议趁热吃，奶油香气会更明显。",
        "available": True
    },
    {
        "id": 2,
        "name": "黑椒牛肉饭",
        "category": "主食",
        "price": 38,
        "desc": "厚切牛肉搭配黑椒酱汁，肉香浓郁，适合午餐。",
        "tags": ["热销", "可外带"],
        "image": "https://images.unsplash.com/photo-1543352634-a1c51d9f1fa7?auto=format&fit=crop&w=900&q=80",
        "specs": [{"name": "标准份", "price": 38}, {"name": "大份", "price": 48}],
        "tastes": ["不辣", "微辣", "中辣", "不要洋葱"],
        "addons": [{"name": "加蛋", "price": 3}, {"name": "加牛肉", "price": 12}],
        "chefNote": "米饭少一点也很好吃，酱汁会更集中。",
        "available": True
    },
    {
        "id": 3,
        "name": "桂花酒酿拿铁",
        "category": "饮品",
        "price": 28,
        "desc": "淡淡桂花香气，带一点酒酿的微醺感。",
        "tags": ["新品", "老板推荐"],
        "image": "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=900&q=80",
        "specs": [{"name": "中杯", "price": 28}, {"name": "大杯", "price": 34}],
        "tastes": ["无糖", "三分糖", "五分糖", "少冰", "去冰"],
        "addons": [{"name": "加燕麦奶", "price": 4}, {"name": "加桂花冻", "price": 5}],
        "chefNote": "五分糖、少冰最能保留桂花和咖啡的平衡。",
        "available": True
    },
    {
        "id": 4,
        "name": "焦糖巴斯克",
        "category": "甜品",
        "price": 36,
        "desc": "焦糖外皮与绵密芝士内芯，适合饭后慢慢享用。",
        "tags": ["限量", "售完即止"],
        "image": "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=900&q=80",
        "specs": [{"name": "单块", "price": 36}, {"name": "四寸", "price": 128}],
        "tastes": ["正常甜", "少甜"],
        "addons": [{"name": "加奶油", "price": 4}, {"name": "加莓果", "price": 8}],
        "chefNote": "冷藏 10 分钟后吃，芝士口感会更细。",
        "available": True
    },
    {
        "id": 5,
        "name": "双人晚餐套餐",
        "category": "套餐",
        "price": 268,
        "desc": "前菜、主菜、甜品和饮品各两份，适合今晚慢慢享用。",
        "tags": ["预约制", "双人"],
        "image": "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=80",
        "specs": [{"name": "双人套餐", "price": 268}, {"name": "家庭套餐", "price": 428}],
        "tastes": ["正常", "少油", "少盐", "不吃香菜"],
        "addons": [{"name": "升级甜品", "price": 28}, {"name": "加主菜", "price": 58}],
        "chefNote": "建议提前两小时预约，出餐节奏会更完整。",
        "available": True
    },
    {
        "id": 6,
        "name": "伯爵红茶司康",
        "category": "小吃",
        "price": 22,
        "desc": "外酥内松，茶香干净，搭配奶油和果酱。",
        "tags": ["下午茶", "私房推荐"],
        "image": "https://images.unsplash.com/photo-1519915028121-7d3463d20b13?auto=format&fit=crop&w=900&q=80",
        "specs": [{"name": "一枚", "price": 22}, {"name": "三枚礼盒", "price": 58}],
        "tastes": ["常温", "加热", "少糖"],
        "addons": [{"name": "加凝脂奶油", "price": 6}, {"name": "加手作果酱", "price": 6}],
        "chefNote": "加热后掰开，先闻到的是伯爵茶香。",
        "available": True
    }
]


DEFAULT_ORDERS = []


def ensure_store():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(STORE_PATH):
        write_store({
            "dishes": DEFAULT_DISHES,
            "orders": DEFAULT_ORDERS,
            "adminPassword": DEFAULT_PASSWORD
        })


def read_store():
    ensure_store()
    with open(STORE_PATH, "r", encoding="utf-8") as file:
        return json.load(file)


def write_store(data):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = STORE_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=2)
    os.replace(tmp, STORE_PATH)


def next_order_id(store):
    nums = []
    for order in store.get("orders", []):
        raw = str(order.get("id", "A1000"))
        if raw.startswith("A") and raw[1:].isdigit():
            nums.append(int(raw[1:]))
    return "A{}".format((max(nums) if nums else 1030) + 1)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/state":
            store = read_store()
            self.json_response({
                "dishes": store.get("dishes", []),
                "orders": store.get("orders", [])
            })
            return
        parts = [part for part in path.split("/") if part]
        if len(parts) == 3 and parts[:2] == ["api", "orders"]:
            store = read_store()
            for order in store.get("orders", []):
                if str(order.get("id")) == parts[2]:
                    self.json_response(order)
                    return
            self.send_error(404)
            return
        super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/orders":
            store = read_store()
            order = self.read_json()
            order["id"] = next_order_id(store)
            store.setdefault("orders", []).insert(0, order)
            write_store(store)
            self.json_response(order)
            return
        if path == "/api/dishes":
            store = read_store()
            dish = self.read_json()
            ids = [int(item.get("id", 0)) for item in store.get("dishes", []) if str(item.get("id", "")).isdigit()]
            dish["id"] = (max(ids) if ids else 1000) + 1
            dish["custom"] = True
            dish.setdefault("available", True)
            store.setdefault("dishes", []).insert(0, dish)
            write_store(store)
            self.json_response(dish)
            return
        if path == "/api/admin/login":
            store = read_store()
            payload = self.read_json()
            self.json_response({"ok": payload.get("password") == store.get("adminPassword", DEFAULT_PASSWORD)})
            return
        if path == "/api/admin/password":
            store = read_store()
            payload = self.read_json()
            if payload.get("oldPassword") != store.get("adminPassword", DEFAULT_PASSWORD):
                self.json_response({"ok": False, "message": "当前密码不正确"}, status=403)
                return
            store["adminPassword"] = payload.get("newPassword") or DEFAULT_PASSWORD
            write_store(store)
            self.json_response({"ok": True})
            return
        self.send_error(404)

    def do_PATCH(self):
        path = urlparse(self.path).path
        parts = [part for part in path.split("/") if part]
        if len(parts) == 3 and parts[:2] == ["api", "orders"]:
            store = read_store()
            payload = self.read_json()
            for order in store.get("orders", []):
                if str(order.get("id")) == parts[2]:
                    order.update(payload)
                    write_store(store)
                    self.json_response(order)
                    return
            self.send_error(404)
            return
        if len(parts) == 3 and parts[:2] == ["api", "dishes"]:
            store = read_store()
            payload = self.read_json()
            for dish in store.get("dishes", []):
                if str(dish.get("id")) == parts[2]:
                    dish.update(payload)
                    write_store(store)
                    self.json_response(dish)
                    return
            self.send_error(404)
            return
        self.send_error(404)

    def do_DELETE(self):
        path = urlparse(self.path).path
        parts = [part for part in path.split("/") if part]
        if len(parts) == 3 and parts[:2] == ["api", "dishes"]:
            store = read_store()
            before = len(store.get("dishes", []))
            store["dishes"] = [dish for dish in store.get("dishes", []) if str(dish.get("id")) != parts[2] or not dish.get("custom")]
            write_store(store)
            self.json_response({"ok": len(store["dishes"]) != before})
            return
        self.send_error(404)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length).decode("utf-8") if length else "{}"
        return json.loads(raw or "{}")

    def json_response(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main():
    ensure_store()
    host = "0.0.0.0"
    port = int(os.environ.get("PORT", "4173"))
    print("私宴 Menu running at http://{}:{}/".format(host, port))
    ThreadingHTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
