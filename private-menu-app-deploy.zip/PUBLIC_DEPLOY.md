# 公网同步部署说明

如果客户手机和老板手机不在同一个 Wi-Fi，需要把 `server.py` 部署到公网 HTTPS 服务器。

## 为什么必须有公网后端

客户手机下单后，订单必须写到一个双方都能访问的位置。

- 同一局域网：客户和老板都访问老板电脑的 `http://电脑IP:4173`
- 不同网络：必须部署到公网，例如 `https://menu.example.com`

没有公网后端时，客户手机和老板手机各自只看到自己的本地数据，无法同步。

## 服务器运行方式

上传整个 `private-menu-app` 目录后，在服务器运行：

```bash
cd private-menu-app
PORT=4173 python3 server.py
```

再用 Nginx / 宝塔 / 反向代理把 HTTPS 域名转发到 `127.0.0.1:4173`。

## 阿里云构建包注意

如果平台日志里出现：

```text
does not appear to be a Python project: neither 'setup.py' nor 'pyproject.toml' found
```

说明平台正在用 `pip install` 安装上传的 zip 包。当前项目已经补充 `setup.py`，请上传最新的：

```text
/Users/wuxinyang/Documents/1/private-menu-app-deploy.zip
```

不要上传旧压缩包，也不要只上传 `index.html`、`app.js` 等静态文件。

## 前端 API 地址

如果前端和后端部署在同一个域名下，不需要额外配置。

如果前端单独部署在静态网站，后端在另一个域名，可以在 `index.html` 加：

```html
<script>
  window.PRIVATE_MENU_API_BASE = "https://你的后端域名";
</script>
```

这行要放在 `app.js` 之前。

## 客户端取餐进度

客户提交订单后，App 会保存订单号，并每 4 秒从后端同步订单状态。

老板端修改状态后：

```text
新订单 → 已接单 → 制作中 → 待取餐 → 已完成
```

客户自己的订单页会自动更新进度。

## 数据文件

后端数据保存在：

```text
data/store.json
```

正式商用建议后续升级为 MySQL / PostgreSQL / 云数据库。
