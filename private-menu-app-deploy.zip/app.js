const DEFAULT_ADMIN_PASSWORD = "123456";
const API_BASE = (window.PRIVATE_MENU_API_BASE || localStorage.getItem("privateMenuApiBase") || "").replace(/\/$/, "");
const STORAGE_KEYS = {
  dishes: "privateMenuDishes",
  legacyCustomDishes: "privateMenuCustomDishes",
  orders: "privateMenuOrders",
  adminPassword: "privateMenuAdminPassword",
  adminSession: "privateMenuAdminSession",
  customerOrderId: "privateMenuCustomerOrderId"
};

const dishes = [
  {
    id: 1,
    name: "黑松露奶油意面",
    category: "今日限定",
    price: 68,
    desc: "奶油酱低温慢熬，搭配黑松露香气，入口浓郁但不厚重。",
    tags: ["招牌", "今日限定", "主厨推荐"],
    image: "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=80",
    specs: [{ name: "单人份", price: 68 }, { name: "双人份", price: 118 }],
    tastes: ["正常", "少盐", "少油"],
    addons: [{ name: "加芝士", price: 5 }, { name: "加虾仁", price: 15 }, { name: "加温泉蛋", price: 6 }],
    chefNote: "这道菜建议趁热吃，奶油香气会更明显。"
  },
  {
    id: 2,
    name: "黑椒牛肉饭",
    category: "主食",
    price: 38,
    desc: "厚切牛肉搭配黑椒酱汁，肉香浓郁，适合午餐。",
    tags: ["热销", "可外带"],
    image: "https://images.unsplash.com/photo-1543352634-a1c51d9f1fa7?auto=format&fit=crop&w=900&q=80",
    specs: [{ name: "标准份", price: 38 }, { name: "大份", price: 48 }],
    tastes: ["不辣", "微辣", "中辣", "不要洋葱"],
    addons: [{ name: "加蛋", price: 3 }, { name: "加牛肉", price: 12 }],
    chefNote: "米饭少一点也很好吃，酱汁会更集中。"
  },
  {
    id: 3,
    name: "桂花酒酿拿铁",
    category: "饮品",
    price: 28,
    desc: "淡淡桂花香气，带一点酒酿的微醺感。",
    tags: ["新品", "老板推荐"],
    image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=900&q=80",
    specs: [{ name: "中杯", price: 28 }, { name: "大杯", price: 34 }],
    tastes: ["无糖", "三分糖", "五分糖", "少冰", "去冰"],
    addons: [{ name: "加燕麦奶", price: 4 }, { name: "加桂花冻", price: 5 }],
    chefNote: "五分糖、少冰最能保留桂花和咖啡的平衡。"
  },
  {
    id: 4,
    name: "焦糖巴斯克",
    category: "甜品",
    price: 36,
    desc: "焦糖外皮与绵密芝士内芯，适合饭后慢慢享用。",
    tags: ["限量", "售完即止"],
    image: "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=900&q=80",
    specs: [{ name: "单块", price: 36 }, { name: "四寸", price: 128 }],
    tastes: ["正常甜", "少甜"],
    addons: [{ name: "加奶油", price: 4 }, { name: "加莓果", price: 8 }],
    chefNote: "冷藏 10 分钟后吃，芝士口感会更细。"
  },
  {
    id: 5,
    name: "双人晚餐套餐",
    category: "套餐",
    price: 268,
    desc: "前菜、主菜、甜品和饮品各两份，适合今晚慢慢享用。",
    tags: ["预约制", "双人"],
    image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=80",
    specs: [{ name: "双人套餐", price: 268 }, { name: "家庭套餐", price: 428 }],
    tastes: ["正常", "少油", "少盐", "不吃香菜"],
    addons: [{ name: "升级甜品", price: 28 }, { name: "加主菜", price: 58 }],
    chefNote: "建议提前两小时预约，出餐节奏会更完整。"
  },
  {
    id: 6,
    name: "伯爵红茶司康",
    category: "小吃",
    price: 22,
    desc: "外酥内松，茶香干净，搭配奶油和果酱。",
    tags: ["下午茶", "私房推荐"],
    image: "https://images.unsplash.com/photo-1519915028121-7d3463d20b13?auto=format&fit=crop&w=900&q=80",
    specs: [{ name: "一枚", price: 22 }, { name: "三枚礼盒", price: 58 }],
    tastes: ["常温", "加热", "少糖"],
    addons: [{ name: "加凝脂奶油", price: 6 }, { name: "加手作果酱", price: 6 }],
    chefNote: "加热后掰开，先闻到的是伯爵茶香。"
  }
];

const state = {
  category: "全部",
  search: "",
  cart: [],
  orders: [
    { id: "A1028", customer: "李女士", phone: "13800001028", total: 86, method: "自提", time: "18:30", status: "新订单", paid: true, createdAt: todayTime("10:18"), items: "黑椒牛肉饭 x1，桂花酒酿拿铁 x1" },
    { id: "A1029", customer: "陈先生", phone: "13800001029", total: 268, method: "堂食", time: "19:00", status: "制作中", paid: true, createdAt: todayTime("11:42"), items: "双人晚餐套餐 x1" },
    { id: "A1030", customer: "张女士", phone: "13800001030", total: 58, method: "外带", time: "立即", status: "待取餐", paid: true, createdAt: todayTime("12:06"), items: "伯爵红茶司康 x1，桂花酒酿拿铁 x1" }
  ],
  currentOrder: null,
  adminAuthed: sessionStorage.getItem(STORAGE_KEYS.adminSession) === "ok",
  apiOnline: false
};

const qs = (selector) => document.querySelector(selector);
const qsa = (selector) => [...document.querySelectorAll(selector)];
const yuan = (value) => `¥${value}`;

async function init() {
  loadSavedDishes();
  loadSavedOrders();
  loadCustomerOrder();
  await syncFromServer();
  renderCategories();
  renderFeatured();
  renderDishes();
  renderFavorites();
  renderAdmin();
  bindEvents();
  updateCart();
  setInterval(refreshSharedData, 4000);
}

function bindEvents() {
  qs("#searchInput").addEventListener("input", (event) => {
    state.search = event.target.value.trim();
    renderDishes();
  });

  document.addEventListener("click", (event) => {
    const target = event.target.closest("[data-action], [data-dish], [data-category], [data-panel]");
    if (!target) return;

    const action = target.dataset.action;
    const dishId = Number(target.dataset.dish);

    if (target.dataset.category) {
      state.category = target.dataset.category;
      renderCategories();
      renderDishes();
    }

    if (target.dataset.panel) {
      openPanel(target.dataset.panel);
    }

    if (dishId && !action) openDish(dishId);
    if (action === "close-modal") hide(qs("#detailModal"));
    if (action === "open-cart") openCart();
    if (action === "close-cart") hide(qs("#cartDrawer"));
    if (action === "clear-cart") {
      state.cart = [];
      updateCart();
      openCart();
    }
    if (action === "checkout") checkout();
    if (action === "back-home") showScreen("customerView");
    if (action === "show-admin") openAdmin();
    if (action === "login-admin") loginAdmin();
    if (action === "logout-admin") logoutAdmin();
    if (action === "change-password") openPasswordForm();
    if (action === "save-password") saveAdminPassword();
    if (action === "add-sample-dish") addSampleDish();
    if (action === "create-dish") createDishFromForm();
    if (action === "next-status") nextOrderStatus(target.dataset.order);
    if (action === "cancel-order") cancelOrder(target.dataset.order);
    if (action === "view-order") openOrderDetail(target.dataset.order);
    if (action === "toggle-dish") toggleDish(target.dataset.dishId);
    if (action === "delete-dish") deleteDish(target.dataset.dishId);
  });
}

async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  if (!response.ok) throw new Error(`API ${path} ${response.status}`);
  return response.json();
}

async function syncFromServer() {
  try {
    const data = await apiFetch("/api/state");
    state.apiOnline = true;
    if (Array.isArray(data.dishes)) {
      dishes.splice(0, dishes.length, ...data.dishes.map(normalizeDish));
      saveDishes();
    }
    if (Array.isArray(data.orders)) {
      state.orders = data.orders.map(normalizeOrder);
      saveOrders();
      syncCurrentOrder();
    }
  } catch {
    state.apiOnline = false;
  }
}

async function refreshSharedData() {
  await syncFromServer();
  renderCategories();
  renderFeatured();
  renderDishes();
  renderFavorites();
  if (state.currentOrder) renderOrder();
  if (state.adminAuthed) renderAdmin();
}

function syncCurrentOrder() {
  const orderId = state.currentOrder?.id || localStorage.getItem(STORAGE_KEYS.customerOrderId);
  if (!orderId) return;
  const latest = state.orders.find((order) => order.id === orderId);
  if (latest) {
    state.currentOrder = {
      ...state.currentOrder,
      ...latest,
      items: state.currentOrder?.items || latest.itemsDetail || []
    };
  }
}

function loadCustomerOrder() {
  const orderId = localStorage.getItem(STORAGE_KEYS.customerOrderId);
  if (!orderId) return;
  const order = state.orders.find((item) => item.id === orderId);
  if (order) {
    state.currentOrder = {
      ...order,
      items: order.itemsDetail || []
    };
  }
}

function todayTime(time) {
  const date = new Date();
  const [hour, minute] = time.split(":");
  date.setHours(Number(hour), Number(minute), 0, 0);
  return date.toISOString();
}

function loadSavedDishes() {
  try {
    const savedAll = JSON.parse(localStorage.getItem(STORAGE_KEYS.dishes) || "null");
    if (Array.isArray(savedAll) && savedAll.length) {
      dishes.splice(0, dishes.length, ...savedAll);
      return;
    }
    const savedCustom = JSON.parse(localStorage.getItem(STORAGE_KEYS.legacyCustomDishes) || "[]");
    savedCustom.forEach((dish) => {
      if (!dishes.some((item) => item.id === dish.id)) dishes.unshift(dish);
    });
  } catch {
    localStorage.removeItem(STORAGE_KEYS.dishes);
  }
  dishes.forEach(normalizeDish);
}

function saveDishes() {
  localStorage.setItem(STORAGE_KEYS.dishes, JSON.stringify(dishes));
}

function normalizeDish(dish) {
  if (dish.available === undefined) dish.available = true;
  if (!dish.tags?.length) dish.tags = ["新品"];
  if (!dish.specs?.length) dish.specs = [{ name: "标准份", price: dish.price }];
  if (!dish.tastes?.length) dish.tastes = ["正常"];
  if (!dish.addons) dish.addons = [];
  return dish;
}

function loadSavedOrders() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEYS.orders) || "null");
    if (Array.isArray(saved)) state.orders = saved;
  } catch {
    localStorage.removeItem(STORAGE_KEYS.orders);
  }
  state.orders = state.orders.map(normalizeOrder);
}

function saveOrders() {
  localStorage.setItem(STORAGE_KEYS.orders, JSON.stringify(state.orders));
}

function normalizeOrder(order) {
  return {
    customer: "张女士",
    phone: "13800000000",
    paid: true,
    createdAt: new Date().toISOString(),
    ...order
  };
}

function renderCategories() {
  const categories = ["全部", ...new Set(dishes.map((dish) => dish.category))];
  qs("#categoryTabs").innerHTML = categories.map((category) => `
    <button class="${state.category === category ? "active" : ""}" data-category="${category}">${category}</button>
  `).join("");
}

function renderFeatured() {
  qs("#featuredList").innerHTML = dishes
    .filter((dish) => dish.available && dish.tags.some((tag) => ["招牌", "今日限定", "老板推荐", "限量"].includes(tag)))
    .slice(0, 4)
    .map((dish) => `
      <article class="featured-card" style="background-image: url('${dish.image}')">
        <span>${dish.tags[0]}</span>
        <h4>${dish.name}</h4>
        <p>${dish.desc}</p>
        <button class="gold-btn small" data-dish="${dish.id}">${yuan(dish.price)} 点这道</button>
      </article>
    `).join("");
}

function filteredDishes() {
  return dishes.filter((dish) => {
    const byCategory = state.category === "全部" || dish.category === state.category;
    const blob = `${dish.name} ${dish.desc} ${dish.tags.join(" ")} ${dish.tastes.join(" ")}`;
    return byCategory && blob.includes(state.search);
  });
}

function renderDishes() {
  const list = filteredDishes();
  qs("#dishCount").textContent = `${list.length} 道可选`;
  qs("#dishList").innerHTML = list.map(dishCard).join("") || `<p class="muted">没有找到相关菜品。</p>`;
}

function dishCard(dish) {
  return `
    <article class="dish-card" data-dish="${dish.id}">
      <img class="dish-img" src="${dish.image}" alt="${dish.name}" />
      <div class="dish-info">
        <h4>${dish.name}</h4>
        <p>${dish.desc}</p>
        <div class="tags">
          ${dish.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
          ${dish.available ? "" : `<span class="tag soldout">今日售罄</span>`}
        </div>
        <div class="dish-foot">
          <span class="price">${yuan(dish.price)}</span>
          <button class="add-btn" data-dish="${dish.id}" ${dish.available ? "" : "disabled"} aria-label="选择 ${dish.name} 的口味和备注">${dish.available ? "+" : "×"}</button>
        </div>
      </div>
    </article>
  `;
}

function openDish(id) {
  const dish = dishes.find((item) => item.id === id);
  if (!dish) return;
  if (!dish.available) {
    toast("这道菜今日已售罄");
    return;
  }
  const modal = qs("#detailModal");
  const defaultSpec = dish.specs[0];

  modal.innerHTML = `
    <article class="modal-card">
      <div class="modal-hero" style="background-image: url('${dish.image}')"></div>
      <div class="modal-body">
        <div class="modal-title-row">
          <div>
            <h2>${dish.name}</h2>
            <span class="price">${yuan(defaultSpec.price)}</span>
          </div>
          <button class="close-btn" data-action="close-modal">×</button>
        </div>
        <p>${dish.desc}</p>
        <div class="tags">${dish.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}</div>
        <div class="option-group">
          <h4>老板推荐语</h4>
          <p class="muted">${dish.chefNote}</p>
        </div>
        ${choiceGroup("规格", "spec", dish.specs.map((spec) => `${spec.name} ${yuan(spec.price)}`), 0)}
        ${choiceGroup("口味", "taste", dish.tastes, 0)}
        ${choiceGroup("加料", "addon", dish.addons.map((addon) => `${addon.name} +${yuan(addon.price)}`), -1, true)}
        <div class="option-group">
          <h4>备注</h4>
          <textarea id="dishRemark" rows="3" placeholder="例如：不要葱、少油、打包"></textarea>
        </div>
        <div class="option-group">
          <h4>数量</h4>
          <div class="quantity">
            <button id="minusQty">-</button>
            <strong id="qty">1</strong>
            <button id="plusQty">+</button>
          </div>
        </div>
        <button id="confirmAdd" class="gold-btn">加入购物车</button>
      </div>
    </article>
  `;

  show(modal);
  let qty = 1;
  qs("#minusQty").onclick = () => {
    qty = Math.max(1, qty - 1);
    qs("#qty").textContent = qty;
  };
  qs("#plusQty").onclick = () => {
    qty += 1;
    qs("#qty").textContent = qty;
  };
  qsa(".choice").forEach((choice) => {
    choice.onclick = () => {
      if (choice.dataset.multi === "true") {
        choice.classList.toggle("active");
      } else {
        qsa(`.choice[data-group="${choice.dataset.group}"]`).forEach((item) => item.classList.remove("active"));
        choice.classList.add("active");
      }
    };
  });
  qs("#confirmAdd").onclick = () => {
    const specIndex = Number(qs('.choice[data-group="spec"].active').dataset.index);
    const selectedAddons = qsa('.choice[data-group="addon"].active').map((item) => dish.addons[Number(item.dataset.index)]);
    const spec = dish.specs[specIndex];
    const taste = qs('.choice[data-group="taste"].active').textContent;
    const remark = qs("#dishRemark").value.trim();
    const addonTotal = selectedAddons.reduce((sum, addon) => sum + addon.price, 0);

    addToCart({
      dishId: dish.id,
      name: dish.name,
      spec: spec.name,
      taste,
      remark,
      addons: selectedAddons,
      qty,
      unitPrice: spec.price + addonTotal
    });
    hide(modal);
  };
}

function choiceGroup(title, group, options, activeIndex = 0, multi = false) {
  return `
    <div class="option-group">
      <h4>${title}</h4>
      <div class="choice-grid">
        ${options.map((option, index) => `
          <button class="choice ${index === activeIndex ? "active" : ""}" data-group="${group}" data-index="${index}" data-multi="${multi}">${option}</button>
        `).join("")}
      </div>
    </div>
  `;
}

function updateCart() {
  const count = state.cart.reduce((sum, item) => sum + item.qty, 0);
  const total = state.cart.reduce((sum, item) => sum + item.qty * item.unitPrice, 0);
  qs("#cartCount").textContent = count;
  qs("#cartTotal").textContent = yuan(total);
  qs("#cartBar").classList.toggle("hidden", count === 0);
}

function addToCart(item) {
  state.cart.push(item);
  updateCart();
  toast(`${item.name} 已加入购物车`);
}

function openCart() {
  const drawer = qs("#cartDrawer");
  const total = state.cart.reduce((sum, item) => sum + item.qty * item.unitPrice, 0);
  const content = state.cart.length ? state.cart.map((item, index) => `
    <div class="cart-item">
      <div>
        <h4>${item.name} ×${item.qty}</h4>
        <p>规格：${item.spec}</p>
        <p>口味：${item.taste}${item.addons.length ? `，${item.addons.map((addon) => addon.name).join("，")}` : ""}</p>
        ${item.remark ? `<p>备注：${item.remark}</p>` : ""}
      </div>
      <strong>${yuan(item.unitPrice * item.qty)}</strong>
    </div>
  `).join("") : `<p class="muted">购物车还是空的，先选一道今日主推吧。</p>`;

  drawer.innerHTML = `
    <section class="drawer-panel">
      <div class="section-title compact">
        <div>
          <p>Cart</p>
          <h3>购物车</h3>
        </div>
        <button class="close-btn" data-action="close-cart">×</button>
      </div>
      ${content}
      <div class="option-group">
        <h4>用餐方式</h4>
        <select id="diningMethod">
          <option>自提</option>
          <option>堂食</option>
          <option>外带</option>
          <option>配送</option>
        </select>
      </div>
      <div class="option-group">
        <h4>取餐时间</h4>
        <select id="pickupTime">
          <option>立即</option>
          <option>今天 18:30</option>
          <option>今天 19:00</option>
          <option>明天 12:00</option>
        </select>
      </div>
      <div class="option-group form-grid-2">
        <label>
          <span>联系人</span>
          <input id="customerName" placeholder="张女士" value="张女士" />
        </label>
        <label>
          <span>手机号</span>
          <input id="customerPhone" placeholder="13800000000" value="13800000000" />
        </label>
      </div>
      <div class="option-group">
        <h4>整单备注</h4>
        <textarea id="orderRemark" rows="2" placeholder="例如：餐具两份、请电话通知"></textarea>
      </div>
      <div class="drawer-actions">
        <button class="gold-btn" data-action="checkout" ${state.cart.length ? "" : "disabled"}>提交订单 · ${yuan(total)}</button>
        <button class="secondary-btn" data-action="clear-cart">清空购物车</button>
      </div>
    </section>
  `;
  show(drawer);
}

async function checkout() {
  if (!state.cart.length) return;
  const total = state.cart.reduce((sum, item) => sum + item.qty * item.unitPrice, 0);
  const method = qs("#diningMethod").value;
  const time = qs("#pickupTime").value;
  const customer = qs("#customerName").value.trim() || "顾客";
  const phone = qs("#customerPhone").value.trim() || "未填写";
  const remark = qs("#orderRemark").value.trim();
  const draftOrder = {
    id: `A${Math.floor(1031 + Math.random() * 800)}`,
    total,
    method,
    time,
    customer,
    phone,
    remark,
    paid: true,
    status: "新订单",
    createdAt: new Date().toISOString(),
    items: [...state.cart],
    itemsText: state.cart.map((item) => `${item.name} x${item.qty}`).join("，")
  };

  let savedOrder = {
    ...draftOrder,
    items: draftOrder.itemsText,
    itemsDetail: [...state.cart]
  };
  try {
    savedOrder = await apiFetch("/api/orders", {
      method: "POST",
      body: JSON.stringify(savedOrder)
    });
    state.apiOnline = true;
  } catch {
    state.apiOnline = false;
    state.orders.unshift(savedOrder);
    saveOrders();
  }

  if (!state.orders.some((order) => order.id === savedOrder.id)) {
    state.orders.unshift(savedOrder);
  }
  state.currentOrder = {
    ...savedOrder,
    items: savedOrder.itemsDetail || draftOrder.items
  };
  localStorage.setItem(STORAGE_KEYS.customerOrderId, state.currentOrder.id);
  state.cart = [];
  updateCart();
  hide(qs("#cartDrawer"));
  renderOrder();
  renderAdmin();
  showScreen("orderView");
}

function renderOrder() {
  const order = state.currentOrder;
  if (!order) {
    qs("#orderContent").innerHTML = `<p class="muted">还没有新订单。提交一单后，这里会出现制作时间轴。</p>`;
    return;
  }
  const steps = ["已下单", "店家已接单", "正在制作", "等待取餐", "已完成"];
  const activeIndex = Math.max(0, ["新订单", "已接单", "制作中", "待取餐", "已完成"].indexOf(order.status));
  qs("#orderContent").innerHTML = `
    <article class="order-card">
      <p class="eyebrow">订单编号 ${order.id}</p>
      <h3>${order.method} · ${order.time}</h3>
      <p class="muted">下单时间 ${formatDateTime(order.createdAt)}，预计 25 分钟内完成。</p>
      <p class="muted">联系人：${order.customer} ｜ ${order.phone}</p>
      ${order.remark ? `<p class="muted">备注：${order.remark}</p>` : ""}
      ${(order.items || []).map((item) => `<p>${item.name} ×${item.qty} <strong>${yuan(item.unitPrice * item.qty)}</strong></p>`).join("")}
      <h3>${yuan(order.total)}</h3>
    </article>
    <div class="timeline">
      ${steps.map((step, index) => `
        <div class="timeline-step ${index <= activeIndex ? "done" : ""}">
          <span class="dot"></span>
          <div>
            <strong>${step}</strong>
            <p class="muted">${index === activeIndex ? "当前状态" : " "}</p>
          </div>
        </div>
      `).join("")}
    </div>
  `;
}

function renderFavorites() {
  qs("#favoriteList").innerHTML = dishes.slice(0, 3).map(dishCard).join("");
}

function renderAdmin() {
  const stats = getAdminStats();
  qs("#adminStats").innerHTML = `
    <div><strong>${stats.todayCount}</strong><span>今日订单</span></div>
    <div><strong>${yuan(stats.todayRevenue)}</strong><span>今日收入</span></div>
    <div><strong>${stats.pendingCount}</strong><span>待处理</span></div>
    <div><strong>${stats.hotDish}</strong><span>热销第一</span></div>
  `;

  qs("#adminOrders").innerHTML = state.orders.map((order) => `
    <article class="admin-order">
      <h4>订单号：${order.id} · ${order.customer}</h4>
      <p>金额：${yuan(order.total)} ｜ ${order.method} ｜ ${order.time} ｜ ${order.paid ? "已支付" : "未支付"}</p>
      <p>电话：${order.phone} ｜ 下单：${formatDateTime(order.createdAt)}</p>
      <p>菜品：${order.items}</p>
      ${order.remark ? `<p>备注：${order.remark}</p>` : ""}
      <div class="admin-actions">
        <button data-action="next-status" data-order="${order.id}" ${["已完成", "已取消"].includes(order.status) ? "disabled" : ""}>${order.status} → 下一步</button>
        <button data-action="cancel-order" data-order="${order.id}" ${["已完成", "已取消"].includes(order.status) ? "disabled" : ""}>取消订单</button>
        <button data-action="view-order" data-order="${order.id}">查看详情</button>
      </div>
    </article>
  `).join("") || `<p class="muted">暂无订单。</p>`;

  qs("#adminDishes").innerHTML = dishes.map((dish) => `
    <article class="admin-dish-row">
      <div>
        <h4>${dish.name}</h4>
        <p>${dish.category} ｜ ${dish.tags.join(" / ")} ｜ ${dish.available ? "在售" : "今日售罄"}</p>
      </div>
      <div class="admin-dish-actions">
        <strong>${yuan(dish.price)}</strong>
        <button data-action="toggle-dish" data-dish-id="${dish.id}">${dish.available ? "设为售罄" : "恢复上架"}</button>
        ${dish.custom ? `<button data-action="delete-dish" data-dish-id="${dish.id}">删除</button>` : ""}
      </div>
    </article>
  `).join("");
}

function getAdminStats() {
  const today = new Date().toDateString();
  const todayOrders = state.orders.filter((order) => new Date(order.createdAt).toDateString() === today);
  const revenueOrders = todayOrders.filter((order) => order.paid && order.status !== "已取消");
  const pendingStatuses = ["新订单", "已接单", "制作中", "待取餐"];
  const sales = new Map();
  revenueOrders.forEach((order) => {
    if (Array.isArray(order.itemsDetail)) {
      order.itemsDetail.forEach((item) => sales.set(item.name, (sales.get(item.name) || 0) + item.qty));
    } else {
      String(order.items || "").split(/[，,]/).forEach((name) => {
        const clean = name.replace(/\sx\d+/, "").trim();
        if (clean) sales.set(clean, (sales.get(clean) || 0) + 1);
      });
    }
  });
  const hotDish = [...sales.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || "暂无";
  return {
    todayCount: todayOrders.length,
    todayRevenue: revenueOrders.reduce((sum, order) => sum + Number(order.total || 0), 0),
    pendingCount: state.orders.filter((order) => pendingStatuses.includes(order.status)).length,
    hotDish
  };
}

function formatDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value || "未知";
  return date.toLocaleString("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}

async function nextOrderStatus(id) {
  const flow = ["新订单", "已接单", "制作中", "待取餐", "已完成"];
  const order = state.orders.find((item) => item.id === id);
  if (!order || order.status === "已取消") return;
  const index = flow.indexOf(order.status);
  order.status = flow[Math.min(index + 1, flow.length - 1)];
  await persistOrderPatch(id, { status: order.status });
  if (state.currentOrder?.id === id) {
    state.currentOrder.status = order.status;
    renderOrder();
  }
  saveOrders();
  renderAdmin();
  toast(`订单 ${id} 已更新为：${order.status}`);
}

async function cancelOrder(id) {
  const order = state.orders.find((item) => item.id === id);
  if (!order || ["已完成", "已取消"].includes(order.status)) return;
  order.status = "已取消";
  await persistOrderPatch(id, { status: "已取消" });
  if (state.currentOrder?.id === id) {
    state.currentOrder.status = "已取消";
    renderOrder();
  }
  saveOrders();
  renderAdmin();
  toast(`订单 ${id} 已取消`);
}

async function persistOrderPatch(id, patch) {
  try {
    await apiFetch(`/api/orders/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify(patch)
    });
    state.apiOnline = true;
  } catch {
    state.apiOnline = false;
  }
  saveOrders();
}

async function toggleDish(id) {
  const dish = dishes.find((item) => String(item.id) === String(id));
  if (!dish) return;
  dish.available = !dish.available;
  await persistDishPatch(id, { available: dish.available });
  saveDishes();
  renderCategories();
  renderFeatured();
  renderDishes();
  renderFavorites();
  renderAdmin();
  toast(`${dish.name} 已${dish.available ? "恢复上架" : "设为售罄"}`);
}

async function deleteDish(id) {
  const index = dishes.findIndex((item) => String(item.id) === String(id));
  if (index < 0 || !dishes[index].custom) return;
  const [removed] = dishes.splice(index, 1);
  try {
    await apiFetch(`/api/dishes/${encodeURIComponent(id)}`, { method: "DELETE" });
    state.apiOnline = true;
  } catch {
    state.apiOnline = false;
  }
  saveDishes();
  renderCategories();
  renderFeatured();
  renderDishes();
  renderFavorites();
  renderAdmin();
  toast(`${removed.name} 已删除`);
}

async function persistDishPatch(id, patch) {
  try {
    await apiFetch(`/api/dishes/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify(patch)
    });
    state.apiOnline = true;
  } catch {
    state.apiOnline = false;
  }
}

function openOrderDetail(id) {
  const order = state.orders.find((item) => item.id === id);
  if (!order) return;
  const items = order.itemsDetail || [];
  const modal = qs("#detailModal");
  modal.innerHTML = `
    <article class="modal-card">
      <div class="modal-body">
        <div class="modal-title-row">
          <div>
            <p class="eyebrow">Order Detail</p>
            <h2>${order.id}</h2>
          </div>
          <button class="close-btn" data-action="close-modal">×</button>
        </div>
        <div class="order-detail-grid">
          <p><strong>客户：</strong>${order.customer}</p>
          <p><strong>电话：</strong>${order.phone}</p>
          <p><strong>金额：</strong>${yuan(order.total)}</p>
          <p><strong>状态：</strong>${order.status}</p>
          <p><strong>方式：</strong>${order.method}</p>
          <p><strong>时间：</strong>${order.time}</p>
          <p><strong>下单：</strong>${formatDateTime(order.createdAt)}</p>
          <p><strong>支付：</strong>${order.paid ? "已支付" : "未支付"}</p>
        </div>
        ${order.remark ? `<p class="order-detail-note"><strong>整单备注：</strong>${order.remark}</p>` : ""}
        <div class="option-group">
          <h4>菜品明细</h4>
          ${items.length ? items.map((item) => `
            <div class="cart-item">
              <div>
                <h4>${item.name} ×${item.qty}</h4>
                <p>规格：${item.spec}</p>
                <p>口味：${item.taste}${item.addons?.length ? `，${item.addons.map((addon) => addon.name).join("，")}` : ""}</p>
                ${item.remark ? `<p>备注：${item.remark}</p>` : ""}
              </div>
              <strong>${yuan(item.unitPrice * item.qty)}</strong>
            </div>
          `).join("") : `<p>${order.items}</p>`}
        </div>
      </div>
    </article>
  `;
  show(modal);
}

function openAdmin() {
  if (state.adminAuthed) {
    renderAdmin();
    showScreen("adminView");
    return;
  }
  const modal = qs("#detailModal");
  modal.innerHTML = `
    <article class="modal-card auth-card">
      <div class="modal-body">
        <div class="modal-title-row">
          <div>
            <p class="eyebrow">Owner Login</p>
            <h2>老板端登录</h2>
          </div>
          <button class="close-btn" data-action="close-modal">×</button>
        </div>
        <p class="muted">请输入老板端密码后进入后台。默认密码：123456</p>
        <div class="admin-dish-form">
          <label>
            <span>老板端密码</span>
            <input id="adminPasswordInput" type="password" placeholder="请输入密码" />
          </label>
        </div>
        <button class="gold-btn" type="button" data-action="login-admin">进入老板端</button>
      </div>
    </article>
  `;
  show(modal);
  setTimeout(() => qs("#adminPasswordInput")?.focus(), 0);
}

async function loginAdmin() {
  const password = qs("#adminPasswordInput")?.value || "";
  let ok = false;
  try {
    const result = await apiFetch("/api/admin/login", {
      method: "POST",
      body: JSON.stringify({ password })
    });
    ok = result.ok;
    state.apiOnline = true;
  } catch {
    state.apiOnline = false;
    const savedPassword = localStorage.getItem(STORAGE_KEYS.adminPassword) || DEFAULT_ADMIN_PASSWORD;
    ok = password === savedPassword;
  }
  if (!ok) return toast("密码不正确");
  state.adminAuthed = true;
  sessionStorage.setItem(STORAGE_KEYS.adminSession, "ok");
  hide(qs("#detailModal"));
  renderAdmin();
  showScreen("adminView");
}

function logoutAdmin() {
  state.adminAuthed = false;
  sessionStorage.removeItem(STORAGE_KEYS.adminSession);
  showScreen("customerView");
  toast("已退出老板端");
}

function openPasswordForm() {
  const modal = qs("#detailModal");
  modal.innerHTML = `
    <article class="modal-card auth-card">
      <div class="modal-body">
        <div class="modal-title-row">
          <div>
            <p class="eyebrow">Security</p>
            <h2>修改老板端密码</h2>
          </div>
          <button class="close-btn" data-action="close-modal">×</button>
        </div>
        <form id="passwordForm" class="admin-dish-form">
          <label>
            <span>当前密码</span>
            <input id="oldAdminPassword" type="password" required placeholder="请输入当前密码" />
          </label>
          <label>
            <span>新密码</span>
            <input id="newAdminPassword" type="password" required minlength="4" placeholder="至少 4 位" />
          </label>
        </form>
        <button class="gold-btn" type="button" data-action="save-password">保存新密码</button>
      </div>
    </article>
  `;
  show(modal);
  setTimeout(() => qs("#oldAdminPassword")?.focus(), 0);
}

async function saveAdminPassword() {
  const form = qs("#passwordForm");
  if (!form || !form.reportValidity()) return;
  const oldPassword = qs("#oldAdminPassword").value;
  const newPassword = qs("#newAdminPassword").value;
  try {
    await apiFetch("/api/admin/password", {
      method: "POST",
      body: JSON.stringify({ oldPassword, newPassword })
    });
    state.apiOnline = true;
  } catch {
    state.apiOnline = false;
    const savedPassword = localStorage.getItem(STORAGE_KEYS.adminPassword) || DEFAULT_ADMIN_PASSWORD;
    if (oldPassword !== savedPassword) return toast("当前密码不正确");
    localStorage.setItem(STORAGE_KEYS.adminPassword, newPassword);
  }
  hide(qs("#detailModal"));
  toast("老板端密码已更新");
}

function addSampleDish() {
  const modal = qs("#detailModal");
  modal.innerHTML = `
    <article class="modal-card">
      <div class="modal-body">
        <div class="modal-title-row">
          <div>
            <p class="eyebrow">Dish Studio</p>
            <h2>新增菜品</h2>
          </div>
          <button class="close-btn" data-action="close-modal">×</button>
        </div>
        <form id="dishForm" class="admin-dish-form">
          <label>
            <span>菜品名称</span>
            <input id="newDishName" required placeholder="例如：番茄牛腩饭" />
          </label>
          <label>
            <span>分类</span>
            <select id="newDishCategory">
              <option>今日限定</option>
              <option>主食</option>
              <option>小吃</option>
              <option>饮品</option>
              <option>甜品</option>
              <option>套餐</option>
            </select>
          </label>
          <label>
            <span>价格</span>
            <input id="newDishPrice" required type="number" min="1" placeholder="38" />
          </label>
          <label>
            <span>标签</span>
            <input id="newDishTags" placeholder="招牌, 今日限定, 老板推荐" />
          </label>
          <label>
            <span>菜品图片地址</span>
            <input id="newDishImage" placeholder="可填 https 图片地址，不填用默认图" />
          </label>
          <label>
            <span>一句话介绍</span>
            <textarea id="newDishDesc" required rows="3" placeholder="番茄慢炖出自然酸甜，牛腩软烂入味。"></textarea>
          </label>
          <label>
            <span>老板推荐语</span>
            <textarea id="newDishChefNote" rows="2" placeholder="这道菜建议趁热吃。"></textarea>
          </label>
        </form>
        <button class="gold-btn" type="button" data-action="create-dish">保存并上架</button>
      </div>
    </article>
  `;
  show(modal);
}

async function createDishFromForm() {
  const form = qs("#dishForm");
  if (!form || !form.reportValidity()) return;

  const name = qs("#newDishName").value.trim();
  const category = qs("#newDishCategory").value;
  const price = Number(qs("#newDishPrice").value);
  const desc = qs("#newDishDesc").value.trim();
  const image = qs("#newDishImage").value.trim() || "https://images.unsplash.com/photo-1543352634-a1c51d9f1fa7?auto=format&fit=crop&w=900&q=80";
  const tags = qs("#newDishTags").value
    .split(/[,，]/)
    .map((tag) => tag.trim())
    .filter(Boolean);
  const chefNote = qs("#newDishChefNote").value.trim() || "这道菜来自今日新鲜食材，建议趁热享用。";

  const dish = {
    id: Date.now(),
    custom: true,
    name,
    category,
    price,
    desc,
    tags: tags.length ? tags : ["新品", "老板推荐"],
    image,
    specs: [{ name: "标准份", price }, { name: "大份", price: price + 10 }],
    tastes: ["正常", "少盐", "少油", "不吃香菜"],
    addons: [{ name: "加蛋", price: 3 }, { name: "加芝士", price: 5 }],
    chefNote
  };
  normalizeDish(dish);

  let savedDish = dish;
  try {
    savedDish = await apiFetch("/api/dishes", {
      method: "POST",
      body: JSON.stringify(dish)
    });
    state.apiOnline = true;
  } catch {
    state.apiOnline = false;
  }

  if (!dishes.some((item) => String(item.id) === String(savedDish.id))) {
    dishes.unshift(normalizeDish(savedDish));
  }
  saveDishes();
  renderCategories();
  renderFeatured();
  renderDishes();
  renderFavorites();
  renderAdmin();
  hide(qs("#detailModal"));
  showScreen("customerView");
  toast(`${name} 已上架`);
}

function openPanel(panel) {
  qsa(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.panel === panel));
  if (panel === "orders") {
    renderOrder();
    showScreen("orderView");
  }
  if (panel === "member") showScreen("memberView");
  if (panel === "menu") showScreen("customerView");
}

function showScreen(id) {
  qsa(".screen").forEach((screen) => screen.classList.remove("active"));
  qs(`#${id}`).classList.add("active");
}

function show(element) {
  element.classList.remove("hidden");
}

function hide(element) {
  element.classList.add("hidden");
}

function toast(message) {
  const el = qs("#toast");
  el.textContent = message;
  show(el);
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => hide(el), 1800);
}

function setupInstallableApp() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {
      console.info("Service worker registration skipped.");
    });
  }

  const installButton = qs("#installAppBtn");
  if (!installButton) return;

  let installPrompt = null;
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    installPrompt = event;
    show(installButton);
  });

  installButton.addEventListener("click", async () => {
    if (!installPrompt) {
      toast("iPhone 请用 Safari 分享按钮，选择“添加到主屏幕”。");
      return;
    }
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null;
    hide(installButton);
  });

  window.addEventListener("appinstalled", () => {
    hide(installButton);
    toast("已安装到手机桌面");
  });
}

init();
setupInstallableApp();
